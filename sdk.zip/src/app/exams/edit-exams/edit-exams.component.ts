import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-exams',
  templateUrl: './edit-exams.component.html',
  styleUrls: ['./edit-exams.component.scss']
})
export class EditExamsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
