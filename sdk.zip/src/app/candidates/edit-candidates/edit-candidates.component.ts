import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-candidates',
  templateUrl: './edit-candidates.component.html',
  styleUrls: ['./edit-candidates.component.scss']
})
export class EditCandidatesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
